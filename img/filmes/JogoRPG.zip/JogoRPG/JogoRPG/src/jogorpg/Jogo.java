package jogorpg;
import java.util.Scanner;
import java.util.ArrayList;

public class Jogo {
    //Objetos:
    GerarArmas Arma = new GerarArmas("", "", "", 0);
    GerarColetaveis Coletaveis = new GerarColetaveis("", "", "", 0);
    GerarInimigo Inimigo = new GerarInimigo("", "", 0, 0, "");
    GerarHeroi Heroi = new GerarHeroi("", "", 0, 0, 0, 0, 0, 0);
    Scanner Input = new Scanner(System.in);
    
    //Listas:
    ArrayList<Integer> pocoesMana = new ArrayList<>();
    ArrayList<Integer> pocoesCura = new ArrayList<>();
    
    //Variáveis:

    //>Jogo:
    boolean bauInicio = false, armaItem = false, gameOver, bauFalso, cura = true, mana = true, municao = true, armadura = true; 
    int dificuldade, rodada, op = 1, batalha;
  
    //>Coletáveis:
    String nomeColetavel, raridadeColetavel, tipoColetavel;
    int qtdColetavel;
    
    //>Armas:
    String nomeArma, tipoArma, raridadeArma;
    double danoArma;
    
    //>Inimigo:
    String racaInimigo, nomeInimigo, elementoInimigo;
    double armaduraInimigo, vidaInimigo, danoInimigo;
    
    //>Herói:
    String armaHeroi;
    double vidaHeroi, danoHeroi, armaduraHeroi, manaHeroi;
    int municaoHeroi;
    
    
    //Jogo em si:
    public void Iniciar(){
        while(op == 1){
        
        //Intro:
        System.out.println("\tGeneric Dungeon");
        System.out.println("\nBem-vindo ao jogo \"Generic Dungeon\"!\nUm RPG situado em uma masmorra perigosa, onde "
                + "você\nprecisa lutar para achar a saída!");

        System.out.println("\n\nAntes de começar, digite seu nome: ");
        
        Heroi.setNome(Input.nextLine());

        System.out.println("\nEscolha a dificuldade:"
                         + "\n[1] - Fácil."
                         + "\n[2] - Normal."
                         + "\n[3] - Difícil."
                         + "\nDigite aqui: ");
        dificuldade = Input.nextInt();
        
        //Geradores:
        Heroi.gerarVida(dificuldade);
        Heroi.gerarArmadura(dificuldade);
        
        //Variáveis:
        vidaHeroi = Heroi.getVida();
        armaduraHeroi = Heroi.getArmadura();
        
        System.out.println("\n\nIntrodução: ");
        System.out.println(Heroi.getNome() + " acorda numa masmorra decrépita e escura, ele observa que a porta de sua cela está aberta por "
                                     + "algum motivo, além de que um baú o faz companhia, que então decide abri-lo...");
        
        //Baú do inicio:
        bauInicio = true;
        gerarBau();
        
        System.out.println("\nDepois de checar o conteúdo desse baú, ele decide sair de sua cela e buscar a saída do lugar fétido que se encontrava...");
        
        //Batalha ou baú: 
        armaItem = false;
        while(batalha <= 3){
            if(gameOver){
                break;
            }
            else{
                int chance = (int) (Math.random() * 100);

                if(chance <= 85){
                    gerarBatalha();
                    batalha++;
                }
                else{
                    gerarBau();
                }
            }
        }
        
        if(gameOver){
            limparTela();
            System.out.println("Infelizmente " + Heroi.getNome() + " não conseguiu escapar da masmorra...\n");
            System.out.println("\n\tFim de Jogo.");
            System.out.println("\nPontuação: " + Heroi.getExp());
        }
        else{
            limparTela();
            System.out.println("\n" + Heroi.getNome() + " conseguiu escapar da masmorra!");
            System.out.println("\n\tFim de Jogo.");
        }        
        
        System.out.println("\n\n\nVocê quer jogar de novo?\n[1] - Sim.\n[2] - Não.\nDigite aqui: ");
        op = Input.nextInt();
            if(op == 1){
                limparTela();
                Input.nextLine();
            }
        }
    }
    
    //Ações:
    public void ataqueInimigo(){
        //Variáveis:
        int chance, chanceAcerto = (int) (Math.random() * 100);
        int[] danoX = {5, 10, 15};
        int[] danoY = {15, 20, 25};
        
        //Dano baseado no inimigo:
        switch(racaInimigo){
            case "Goblin":
                chance = (int) (Math.random() * danoX.length);
                
                danoInimigo = danoX[chance];
            break;
            
            case "Slime":
                chance = (int) (Math.random() * danoX.length);
                
                danoInimigo = danoX[chance];
            break;
            
            case "Esqueleto":
                chance = (int) (Math.random() * danoY.length);
                
                danoInimigo = danoY[chance];
            break;
            
            default:
                chance = (int) (Math.random() * danoY.length);
                
                danoInimigo = danoY[chance];
            break;
        }
        
        //Dano baseado no elemento do inimigo:
        switch(elementoInimigo){
            case "Terra":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 2;
            break;
            
            case "Água":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 0.5;
            break;
            
            case "Fogo":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 1.5;
            break;
            
            case "Ar":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 0.5;
            break;
            
            case "Gelo":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 1;
            break;
            
            case "Eletrico":
                chanceAcerto = (int) (Math.random() * 100);
                danoInimigo += 1.5;
            break;
        } 
        
        //Se acerta ou erra o ataque:
        if(chanceAcerto <= 75){
            if(armaduraHeroi > 0){
                armaduraHeroi -= (danoInimigo + 1.5);
                vidaHeroi -= (danoInimigo - 1.5);
            }else{
                vidaHeroi -= danoInimigo;
            }
            System.out.println(nomeInimigo + " atacou!\n");
        }else{
            System.out.println("O " + nomeInimigo + " errou o ataque!\n");
        }    
    }

    public void ataqueHeroi(){
        //Variáveis:
        int chance;
        municaoHeroi = Heroi.getMunicao();
        manaHeroi = Heroi.getMana();

        switch(armaHeroi){
            case "Arco":
                //Checa munição:
                if(Heroi.getMunicao()> 0){
                    //Checa armadura:
                    if(armaduraInimigo > 0){
                        municaoHeroi--;
                        armaduraInimigo -= (danoHeroi + 1.5);
                        vidaInimigo -= (danoHeroi - 1.5);
                    }else{
                        municaoHeroi--;
                        vidaInimigo -= danoHeroi;
                    }
                    System.out.println(Heroi.getNome() + " atacou!\n");
                }
                else{
                    System.out.println("Você está sem munição!");
                }
            break;
            
            case "Besta":
                //Checa munição:
                if(Heroi.getMunicao()> 0){
                    //Checa armadura:
                    if(armaduraInimigo > 0){
                        municaoHeroi--;
                        armaduraInimigo -= (danoHeroi + 1.5);
                        vidaInimigo -= (danoHeroi - 1.5);
                    }else{
                        municaoHeroi--;
                        vidaInimigo -= danoHeroi;
                    }
                    System.out.println(Heroi.getNome() + " atacou!\n");
                }
                else{
                    System.out.println("Você está sem munição!");
                }
            break;

            case "Cajado":
                //Checa mana:
                if(Heroi.getMana() > 0){
                    if(armaduraInimigo > 0){
                        manaHeroi--;
                        armaduraInimigo -= (danoHeroi + 1.5);
                        vidaInimigo -= (danoHeroi - 1.5);  
                    }else{
                        manaHeroi--;
                        vidaInimigo -= danoHeroi;
                    }
                    System.out.println(Heroi.getNome() + " atacou!\n");
                }
                else{
                    System.out.println("Você está sem mana!");
                }
            break;

            default:
                if(armaduraInimigo > 0){
                    armaduraInimigo -= (danoHeroi + 1.5);
                    vidaInimigo -= (danoHeroi - 1.5);
                }else{
                    vidaInimigo -= danoHeroi;
                }
                System.out.println(Heroi.getNome() + " atacou!\n");
            break;
        }
    }
    
    public void usarPocao(){
        int opPocoes = 0;
        
        System.out.println("\nEscolha qual poção quer usar:"
                         + "\n[1] - Cura."
                         + "\n[2] - Mana."
                         + "\nDigite aqui: ");
        opPocoes = Input.nextInt();
        
        switch(opPocoes){
            case 1:
                if(pocoesCura.isEmpty()){
                    System.out.println("\nVocê não tem poções de cura para usar!");
                }else{
                    if(vidaHeroi == 100){
                        System.out.println("\nVocê está com vida cheia!");
                    }
                    else{
                        if(vidaHeroi + pocoesCura.get(0) > 100){
                            Heroi.setVida(100);
                            System.out.println("\nVocê usou a poção de cura!");
                        }
                        else{
                            Heroi.addVida(pocoesCura.get(0));
                            System.out.println("\nVocê usou a poção de cura!");
                        }
                    }
                    pocoesCura.remove(0);
                }
            break;
            
            case 2:
                if(pocoesMana.isEmpty()){ //Checa se está vazio
                    System.out.println("\nVocê não tem poções de mana para usar!");
                }else{
                    if(manaHeroi == 100){ //Checa se é necessário usar a poção
                        System.out.println("Você está com a mana cheia!\n");
                    }
                    else{
                        if(manaHeroi + pocoesMana.get(0) > 100){
                            Heroi.setMana(100);
                            System.out.println("\nVocê usou a poção de mana!");
                        }
                        else{
                            Heroi.addMana(pocoesMana.get(0));
                            System.out.println("\nVocê usou a poção de mana!");
                        }
                    }
                    pocoesMana.remove(0); //Remove a poção do "inventário" depois de usada
                }
            break;
        }
    }
    
    //Usar para o baú:
    public void gerarBau(){
        //Variáveis:
        int chance = (int) (Math.random() * 100);
        int chanceItem = (int) (Math.random() * 100);
        armaItem = true;
        
        //Se for o baú do início, ele te dá uma arma e um item:
        if(bauInicio){    
            gerarArmas();
            for(int i = 0; i<3; i++){
                gerarColetaveis();
            }
            bauInicio = false;
        }else{
            if(chanceItem < 50){ //50% de ser um item ou arma.
                if(chance < 85){ //85% de chance de ser um item e 15% de sair um slime.
                    gerarColetaveis();
                }else{
                    System.out.println("\nUm inimigo saiu do baú!");
                    Inimigo.setRaca("Slime");
                    bauFalso = true;
                    gerarBatalha();
                }
            }else{
                gerarArmas();
            }
        }
    }
    
    public void gerarColetaveis(){
        //Itens que serão gerados obrigatoriamente no baú do ínicio:
        if(bauInicio){
            if(cura){
                Coletaveis.setNome("Poção pequena de Cura");
                Coletaveis.gerarRaridade();
                Coletaveis.gerarQtd(Coletaveis.getNome(), Coletaveis.getRaridade());
                Coletaveis.gerarTipo(Coletaveis.getNome());
                cura = false;
            }
            else if(mana){
                Coletaveis.setNome("Poção pequena de Mana");
                Coletaveis.gerarRaridade();
                Coletaveis.gerarQtd(Coletaveis.getNome(), Coletaveis.getRaridade());
                Coletaveis.gerarTipo(Coletaveis.getNome());
                mana = false;
            }
            else if(municao){
                Coletaveis.setNome("Punhado de flechas");
                Coletaveis.gerarRaridade();
                Coletaveis.gerarQtd(Coletaveis.getNome(), Coletaveis.getRaridade());
                Coletaveis.gerarTipo(Coletaveis.getNome());
                municao = false;
            }
        }
        else{
            //Geradores:
            Coletaveis.gerarNome();
            Coletaveis.gerarRaridade();
            Coletaveis.gerarQtd(Coletaveis.getNome(), Coletaveis.getRaridade());
            Coletaveis.gerarTipo(Coletaveis.getNome());
        }
        
        //Variáveis:
        nomeColetavel = Coletaveis.getNome();
        qtdColetavel = Coletaveis.getQuantidade();
        tipoColetavel = Coletaveis.getTipo();
        raridadeColetavel = Coletaveis.getRaridade();
        
        System.out.println("\n\n" + Heroi.getNome() + " pegou um(a) " + nomeColetavel + "!");
        System.out.println("|Descrição:\n|Nome: " + nomeColetavel + " |Tipo: " + 
                           tipoColetavel + "\n|Raridade: " + raridadeColetavel + 
                           " |Quantidade: " + qtdColetavel);
        switch(tipoColetavel){
            case "Flechas":
                if(Heroi.getMunicao() + qtdColetavel > 100){ //Isso é para não passar do limite de 100
                    Heroi.setMunicao(100);
                }
                else{
                    Heroi.addMunicao(qtdColetavel);
                }
            break;

            case "Armadura":
                if(Heroi.getArmadura() + qtdColetavel > 100){
                   Heroi.setArmadura(100);
                }
                else{
                    Heroi.addArmadura(qtdColetavel);
                }
            break;

            case "Mana":
                if(pocoesMana.size()>=5){
                    System.out.println("\nQuantidade de poções de mana no máximo!");
                }
                else{
                    pocoesMana.add(qtdColetavel);
                }
            break;

            case "Cura":
                if(pocoesCura.size()>=5){
                   System.out.println("\nQuantidade de poções de cura no máximo!");
                }
                else{
                   pocoesCura.add(qtdColetavel);
                }
            break;
        }
    }
    
    public void gerarArmas(){
        //Geradores:
        Arma.gerarNome();
        Arma.gerarRaridade();
        Arma.gerarTipo(Arma.getNome());
        Arma.gerarDano(Arma.getNome(), Arma.getRaridade());
        
        //Variáveis:
        nomeArma = Arma.getNome();
        tipoArma = Arma.getTipo();
        raridadeArma = Arma.getRaridade();
        danoArma = Arma.getDano();
        
        if(armaItem){
            System.out.println("\n\n" + Heroi.getNome() + " encontrou um(a) " + nomeArma + "!");
            System.out.println("|Descrição:\n|Nome: " + nomeArma + " |Tipo: " + 
                               tipoArma + "\n|Raridade: " + raridadeArma +  " |Dano: " + danoArma);
            
            if(danoHeroi == 0){
                armaHeroi = nomeArma;
                danoHeroi = danoArma;
                
                switch(nomeArma){
                    case "Arco":
                        Heroi.addMunicao(45); //Se pegar uma arma, ela te da um pouco de munição.
                        System.out.println("\n" + Heroi.getNome() + " coletou 45 flechas.");
                        municaoHeroi = Heroi.getMunicao();
                    break;

                    case "Besta":
                        Heroi.addMunicao(45);
                        System.out.println("\n" + Heroi.getNome() + " coletou 45 flechas.");
                        municaoHeroi = Heroi.getMunicao();
                    break;

                    case "Cajado":
                        Heroi.addMana(45);
                        System.out.println("\n" + Heroi.getNome() + " coletou 45 pontos de mana.");
                        manaHeroi = Heroi.getMana();
                    break;
                }
            }
            else{
                System.out.println("\nPegar/substituir arma atual?\n[1] - Sim.\n[2] - Não.\nDigite aqui: ");
                int op = Input.nextInt();

                switch(op){
                    case 1:
                        armaHeroi = nomeArma;
                        danoHeroi = danoArma;
                        switch(nomeArma){
                            case "Arco":
                                Heroi.addMunicao(45); //Se pegar uma arma, ela te da um pouco de munição.
                                System.out.println("\n" + Heroi.getNome() + " coletou 45 flechas.");
                                municaoHeroi = Heroi.getMunicao();
                            break;

                            case "Besta":
                                Heroi.addMunicao(45);
                                System.out.println("\n" + Heroi.getNome() + " coletou 45 flechas.");
                                municaoHeroi = Heroi.getMunicao();
                            break;

                            case "Cajado":
                                Heroi.addMana(45);
                                System.out.println("\n" + Heroi.getNome() + " coletou 45 pontos de mana.");
                                manaHeroi = Heroi.getMana();
                            break;
                        }
                    break;

                    case 2:
                       System.out.println("\nA arma foi deixada no baú...");
                    break;
                }
            }
        }
    }   
    
    //Geradores:
    public void gerarBatalha(){      
        gerarInimigo();
        if(bauFalso){
            Inimigo.setRaca("Slime");
        }
        while(vidaHeroi > 0 || vidaInimigo > 0){   
            System.out.println("\n|Inimigo:" + 
                               "\n|Nome: " + nomeInimigo + 
                               "\n|Vida: " + vidaInimigo + " |Armadura: " + armaduraInimigo);
            ataqueInimigo();
            if(armaduraHeroi < 0){
                armaduraHeroi = 0;
            }
            if(vidaHeroi < 0){
                vidaHeroi = 0;
            }
            //Herói morre/Game Over:
            if(vidaHeroi <= 0){
                gameOver = true;
                break;
            }
            
            System.out.println("\n|Herói:" +
                               "\n|Nome: " + Heroi.getNome() + " |Experiência/Nível: " + Heroi.getExp() + "/" + Heroi.getNivel() +
                               "\n|Vida: " + vidaHeroi + " |Armadura: " + armaduraHeroi +
                               "\n|Mana: " + manaHeroi + " |Munição: " + municaoHeroi);

            System.out.println("\n\nEscolha o que deseja fazer: "
                             + "\n[1] - Atacar."
                             + "\n[2] - Usar poção."
                             + "\nDigite aqui: ");
            int op = Input.nextInt();
           
            switch(op){
                case 1:
                    ataqueHeroi();
                    if(armaduraInimigo < 0){
                        armaduraInimigo = 0;
                    }
                    if(vidaInimigo < 0){
                        vidaInimigo = 0;
                    }
                    limparTela();
                break;

                case 2:
                    usarPocao();
                break;

                default:
                     System.out.println("Digite uma das alternativas...");
                break;
            }
            
            //Inimigo morre:
            if(vidaInimigo <= 0){
                break;
            }
        }
        
        //Drops:
        if(vidaInimigo <= 0){
            int chance, chanceXP;
            int[] municaoV = {5, 10, 15}, expV = {10, 15, 20, 25}, manaV = {20, 25, 30};

            switch(nomeInimigo){
                case "Esqueleto":
                    chance = (int) (Math.random() * municaoV.length);
                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);
                    Heroi.addMunicao(municaoV[chance]);
                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] 
                                     + " de experiência e " + municaoV[chance] + " de flechas!");
                break;

                case "Goblin":
                    expV[0] = 5;
                    expV[1] = 10;
                    expV[2] = 15;
                    expV[3] = 20;

                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);
                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] + " de experiência!");
                break;

                case "Slime":
                    expV[0] = 5;
                    expV[1] = 10;
                    expV[2] = 15;
                    expV[3] = 20;

                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);
                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] + " de experiência!");
                break;

                case "Arqueiro":
                    municaoV[0] = 15;
                    municaoV[1] = 20;
                    municaoV[2] = 25;

                    chance = (int) (Math.random() * municaoV.length);
                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);
                    Heroi.addMunicao(municaoV[chance]);
                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] 
                                     + " de experiência e " + municaoV[chance] + " de flechas!");
                break;

                case "Mago":
                    chance = (int) (Math.random() * manaV.length); 
                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);
                    Heroi.addMana(manaV[chance]);
                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] 
                                     + " de experiência e " + manaV[chance] + " de flechas!");
                break;

                case "Ladrão":
                    chance = (int) (Math.random() * 100);
                    int chanceMun = (int) (Math.random() * municaoV.length); 
                    int chanceMana = (int) (Math.random() * manaV.length); 
                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.setExp(expV[chanceXP]);
                    if(chance >= 50){
                        Heroi.addMana(manaV[chance]);
                        System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] 
                                         + " de experiência e " + manaV[chance] + " de flechas!");
                    }else{
                        Heroi.addMunicao(municaoV[chance]);
                        System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] 
                                         + " de experiência e " + municaoV[chance] + " de flechas!");
                    }
                break;

                case "Espadachim":
                    chanceXP = (int) (Math.random() * expV.length);

                    Heroi.addExp(expV[chanceXP]);

                    System.out.println(nomeInimigo + " foi derrotado! Você ganhou " + expV[chanceXP] + " de experiência!");
                break;
            }
        }
    }
    
    public String gerarInimigo(){
        //Geradores:
        gerarArmas();
        Inimigo.gerarRaca();
        Inimigo.gerarVida(Inimigo.getRaca());
        Inimigo.gerarArmadura(Inimigo.getRaca());
        Inimigo.gerarNome(Inimigo.getRaca(), Arma.getNome());
        Inimigo.gerarElemento(Inimigo.getRaca());
        
        //Variáveis:
        nomeArma = Arma.getNome();
        racaInimigo = Inimigo.getRaca();
        vidaInimigo = Inimigo.getVida();
        armaduraInimigo = Inimigo.getArmadura();
        nomeInimigo = Inimigo.getNome();
        elementoInimigo = Inimigo.getElemento();
        int chance = (int) (Math.random() * 100);
        int chanceInimigo = (int) (Math.random() * 100);
        
       
        if(chance <= 40){//40% de chance de ser um inimigo fraco.
            if(chanceInimigo <= 50){//50% de chance de ser ou um Slime ou Goblin.
                Inimigo.setRaca("Slime");
                Inimigo.gerarVida(Inimigo.getRaca());
                Inimigo.gerarArmadura(Inimigo.getRaca());
                Inimigo.gerarNome(Inimigo.getRaca(), Arma.getNome());
                Inimigo.gerarElemento(Inimigo.getRaca());
                nomeArma = "Nenhuma";
                }
            else{
                Inimigo.setRaca("Goblin");
                Inimigo.gerarVida(Inimigo.getRaca());
                Inimigo.gerarArmadura(Inimigo.getRaca());
                Inimigo.gerarNome(Inimigo.getRaca(), Arma.getNome());
                Inimigo.gerarElemento(Inimigo.getRaca());
            }
        }
        else if(chance > 40 && chance <= 80){//40% de chance de ser um Inimigo médio.
            if(chanceInimigo <= 50){//50% de chance de ser ou um Humano ou Esqueleto.
                Inimigo.setRaca("Humano");
                Inimigo.gerarVida(Inimigo.getRaca());
                Inimigo.gerarArmadura(Inimigo.getRaca());
                Inimigo.gerarNome(Inimigo.getRaca(), Arma.getNome());
                Inimigo.gerarElemento(Inimigo.getRaca());
            }
            else{
                Inimigo.setRaca("Esqueleto");
                Inimigo.gerarVida(Inimigo.getRaca());
                Inimigo.gerarArmadura(Inimigo.getRaca()); 
                Inimigo.gerarNome(Inimigo.getRaca(), Arma.getNome());
                Inimigo.gerarElemento(Inimigo.getRaca());
            }
        }
        
        return "\n" + Inimigo.getNome() + " aparece!";
    }    
    
    //Limpar tela:
    public void limparTela(){
        for(int i = 0; i<100; i++){
            System.out.println("\n");
        }
    }
}