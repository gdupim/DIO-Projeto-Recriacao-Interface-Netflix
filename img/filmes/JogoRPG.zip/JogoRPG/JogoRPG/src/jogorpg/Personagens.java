package jogorpg;
public class Personagens {
    //Variáveis:
    private String nome, raca;
    private double vida = 0, armadura = 0;
    
    //Construtor:
    public Personagens(String nome, String raca, double vida, double armadura){
       this.nome = nome;
       this.raca = raca;
       this.vida = vida;
       this.armadura = armadura;
    }
    
    //Geradores:
    public void gerarRaca(){
        String[] racaV = {"Humano", "Esqueleto", "Goblin", "Slime"};
       
        int i = (int) (Math.random() * racaV.length);
        
        setRaca(racaV[i]);
    }
    
    //Getters:
    public String getNome(){
        return nome;
    }
    
    public String getRaca(){
        return raca;
    }
    
    public double getVida(){
        return vida;
    }
    
    public double getArmadura(){
        return armadura;
    }
    
    //Setters:
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setRaca(String raca){
        this.raca = raca;
    }
    
    public void setVida(double vida){
        this.vida = vida;
    }
    
    public void setArmadura(double armadura){
        this.armadura = armadura;
    }
    
    //Adders:
    public void addVida(double vida){
        this.vida += vida;
    }
    
    public void addArmadura(double armadura){
        this.armadura += armadura;
    }
}   