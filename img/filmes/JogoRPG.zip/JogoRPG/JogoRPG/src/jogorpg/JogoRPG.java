package jogorpg;
public class JogoRPG {
    public static void main(String[] args) {
        Jogo JogoUm = new Jogo();
        
        JogoUm.Iniciar();
    }   
}