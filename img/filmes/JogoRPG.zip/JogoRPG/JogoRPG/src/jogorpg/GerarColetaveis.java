package jogorpg;
public class GerarColetaveis extends Itens{
    //Variáveis:
    private int quantidade = 0;
    
    //Construtor:
    public GerarColetaveis(String nome, String tipo, String raridade, int quantidade){
        super(nome, tipo, raridade);
        this.quantidade = quantidade;
    }
    
    //Geradores:
    public void gerarNome(){
        int i;
        String[] nomeV = {"Poção pequena de Cura", "Poção pequena de Mana", 
                          "Poção grande de Cura", "Poção grande de Mana",
                          "Punhado de flechas", "Aljava de flechas",
                          "Armadura"};
        
        i = (int) (Math.random() * nomeV.length);
        setNome(nomeV[i]);
    }
    
    public void gerarTipo(String nome){
       switch(nome){
           case "Poção pequena de Cura":
               setTipo("Cura");
           break;
           
           case "Poção grande de Cura":
               setTipo("Cura");
           break;
           
           case "Poção pequena de Mana":
               setTipo("Mana");
           break;
           
           case "Poção grande de Mana":
               setTipo("Mana");
           break;
           
           case "Punhado de flechas":
               setTipo("Flechas");
           break;
           
           case "Aljava de flechas":
               setTipo("Flechas");
           break;
           
           default:
               setTipo("Armadura");
           break;
       }
    }
    
    public void gerarQtd(String nome, String raridade){
       switch(nome){
           case "Armadura":
                switch(raridade){
                        case "Comum":
                            setQuantidade(25);
                        break;

                        case "Incomum":
                            setQuantidade(50);
                        break;

                        case "Raro":
                            setQuantidade(100);
                        break;

                        default:
                            setQuantidade(150);
                        break;
                    }
           break;
           
           case "Poção pequena de Cura":
               switch(raridade){
                   case "Comum":
                       setQuantidade(25);
                   break;
                   
                   case "Incomum":
                       setQuantidade(25);
                   break;
                   
                   case "Raro":
                       setQuantidade(30);
                   break;
                   
                   default:
                       setQuantidade(35);
                   break;
               }
           break;
           
           case "Poção grande de Cura":
               switch(raridade){
                   case "Comum":
                       setQuantidade(50);
                   break;
                   
                   case "Incomum":
                       setQuantidade(50);
                   break;
                   
                   case "Raro":
                       setQuantidade(55);
                   break;
                   
                   default:
                       setQuantidade(60);
                   break;
               }
           break;
           
           case "Poção pequena de Mana":
               switch(raridade){
                   case "Comum":
                       setQuantidade(25);
                   break;
                   
                   case "Incomum":
                       setQuantidade(25);
                   break;
                   
                   case "Raro":
                       setQuantidade(30);
                   break;
                   
                   default:
                       setQuantidade(35);
                   break;
               }
           break;
           
           case "Poção grande de Mana":
               switch(raridade){
                   case "Comum":
                       setQuantidade(50);
                   break;
                   
                   case "Incomum":
                       setQuantidade(50);
                   break;
                   
                   case "Raro":
                       setQuantidade(55);
                   break;
                   
                   default:
                       setQuantidade(60);
                   break;
               }
           break;
           
           case "Punhado de flechas":
               switch(raridade){
                   case "Comum":
                       setQuantidade(25);
                   break;
                   
                   case "Incomum":
                       setQuantidade(25);
                   break;
                   
                   case "Raro":
                       setQuantidade(30);
                   break;
                   
                   default:
                       setQuantidade(35);
                   break;
               }
           break;
           
           case "Aljava de flechas":
               switch(raridade){
                   case "Comum":
                       setQuantidade(50);
                   break;
                   
                   case "Incomum":
                       setQuantidade(50);
                   break;
                   
                   case "Raro":
                       setQuantidade(55);
                   break;
                   
                   default:
                       setQuantidade(60);
                   break;
               }
           break;
       } 
    }
    
    //Getters:
    public int getQuantidade(){
        return quantidade;
    }
    
    //Setters:
    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    } 
}