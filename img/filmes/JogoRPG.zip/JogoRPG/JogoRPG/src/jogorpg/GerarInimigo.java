package jogorpg;
public class GerarInimigo extends Personagens{
    //Variáveis:
    private String elemento;

    //Construtor:
    public GerarInimigo(String nome, String raca, double vida, double armadura, String elemento){
        super(nome, raca, vida, armadura);
        this.elemento = elemento;
    }
    
    //Geradores:
    public void gerarNome(String raca, String arma){
        switch(raca){
            case "Esqueleto":
                setNome("Esqueleto");
            break;
            
            case "Goblin":
                setNome("Goblin");
            break;
            
            case "Slime":
                if(elemento != "Elétrico"){
                    setNome("Slime de " + getElemento());
                }else{
                    setNome("Slime " + getElemento());
                }
            break;
            
            default:
                String[] nomeV = {"Arqueiro", "Mago", "Ladrão", "Espadachim"};
                switch(arma){
                    case "Besta":
                        setNome(nomeV[0]);
                    break;
                    
                    case "Arco":
                        setNome(nomeV[0]);
                    break;
                    
                    case "Espada":
                        setNome(nomeV[3]);
                    break;
                    
                    case "Adaga":
                        setNome(nomeV[2]);
                    break;
                    
                    case "Cajado":
                        setNome(nomeV[1]);
                    break;
                }
            break;
        }
    }
    
    public void gerarVida(String raca){
        double[] vidaV = {25, 50, 100};
        
        switch(raca){
            case "Esqueleto":
                setVida(vidaV[1]);
            break;

            case "Goblin":
                setVida(vidaV[0]);
            break;
            
            case "Slime":
                setVida(vidaV[0]);
            break;
            
            default:
                setVida(vidaV[2]);
            break;
        }
    }
    
    public void gerarArmadura(String raca){
        double[] armaduraV = {15, 20, 25, 50};
        int i;
        
        i = (int) (Math.random() * armaduraV.length);
        
        switch(raca){
            case "Esqueleto":
                setArmadura(armaduraV[i]);
            break;
            
            case "Goblin":
                setArmadura(armaduraV[i]);
            break;
            
            case "Slime":
                setArmadura(0);
            break;
            
            default:
                setArmadura(armaduraV[i]);
            break;
        }
    }
    
    public void gerarElemento(String raca){
        String[] elementoV = {"Terra", "Água", "Fogo", "Ar", "Gelo", "Elétrico"};
        int i;
        i = (int) (Math.random() * elementoV.length);
        
        if(raca != "Slime"){
            setElemento("Nenhum");
        }else{
            setElemento(elementoV[i]);
        }
    }
    
    //Getters:
    public String getElemento(){
        return elemento;
    }
    
    //Setters:
    public void setElemento(String elemento){
        this.elemento = elemento;
    }
}