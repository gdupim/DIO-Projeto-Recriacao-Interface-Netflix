package jogorpg;
public class Itens {
    //Variáveis:
    private String nome, tipo, raridade;

    //Construtor:
    public Itens(String nome, String tipo, String raridade){
       this.nome = nome;
       this.tipo = tipo;
       this.raridade = raridade;
    }

    //Gerador:
    public void gerarRaridade(){
        int i; 
        String[] raridadeV = {"Comum", "Incomum", "Raro", "Lendário"};
        i = (int) (Math.random() * raridadeV.length); //Escolhe e põe a raridade aleatoriamente.
        setRaridade(raridadeV[i]);
    }
    
    //Getters:
    public String getNome(){
        return nome;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public String getRaridade(){
        return raridade;
    }
    
    //Setters:
    public void setNome(String nome){
         this.nome = nome;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    public void setRaridade(String raridade){
        this.raridade = raridade;
    }   
}