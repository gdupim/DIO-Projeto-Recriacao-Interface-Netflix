package jogorpg;
public class GerarArmas extends Itens{
    //Variáveis:
    private double dano = 0;
    
    //Construtor:
    public GerarArmas(String nome, String tipo, String raridade, double dano){
        super(nome, tipo, raridade);
        this.dano = dano;
    }
    
    //Geradores:
    public void gerarNome(){
        int i;
        String[] nomeV = {"Cajado", "Arco", "Besta", "Espada", "Adaga"};
        
        i = (int) (Math.random() * nomeV.length);
        
        setNome(nomeV[i]);
    }
    
    public void gerarTipo(String nome){
        if(nome == "Cajado" || nome == "Arco" || nome == "Besta"){
           setTipo("Arma de longa distância");
        }else{
           setTipo("Arma branca");
        }
    }
    
    public void gerarDano(String nome, String raridade){
        int i;
        
        switch(nome){
            case "Besta":
                //Dano por raridade:
                switch(raridade){
                    case "Comum":
                        //Danos:
                        double[] danoVCB = {5, 5.5, 7};
                        
                        i = (int) (Math.random() * danoVCB.length);       
                        
                        setDano(danoVCB[i]);
                    break;
                    
                    case "Incomum":
                        double[] danoVIB = {8, 9.5, 11};
                        
                        i = (int) (Math.random() * danoVIB.length);       
                            
                        setDano(danoVIB[i]);
                    break;
                    
                    case "Raro":
                        double[] danoVRB = {11.5, 12, 14};
                        
                        i = (int) (Math.random() * danoVRB.length);       
                            
                        setDano(danoVRB[i]);
                    break;
                    
                    case "Lendário": 
                        double[] danoVLB = {18.5, 19.5, 22};
                        
                        i = (int) (Math.random() * danoVLB.length);       
                            
                        setDano(danoVLB[i]);
                    break;
                }
            break;
            
            case "Adaga":
                //Dano por raridade:
                switch(getRaridade()){
                    case "Comum":
                        //Danos:
                        double[] danoVCA = {3, 4.5, 6};
                        
                        i = (int) (Math.random() * danoVCA.length);       
                        
                        setDano(danoVCA[i]);
                    break;
                    
                    case "Incomum":
                        double[] danoVIA = {7, 7.5, 8.5};
                        
                        i = (int) (Math.random() * danoVIA.length);       
                        
                        setDano(danoVIA[i]);
                    break;
                    
                    case "Raro":
                        double[] danoVRA = {10, 11, 11.5};
                        
                        i = (int) (Math.random() * danoVRA.length);       
                            
                        setDano(danoVRA[i]);
                    break;
                    
                    case "Lendário": 
                        double[] danoVLA = {12.5, 13, 14};
                        
                        i = (int) (Math.random() * danoVLA.length);       
                            
                        setDano(danoVLA[i]);
                    break;
                }
            break;
            
            case "Cajado":
                //Dano por raridade:
                switch(getRaridade()){
                    case "Comum":
                        //Danos:
                        double[] danoVCC = {4.5, 5.5, 6.5};
                        
                        i = (int) (Math.random() * danoVCC.length);       
                            
                        setDano(danoVCC[i]);
                    break;
                    
                    case "Incomum":
                        double[] danoVIC = {8.5, 10.5, 11};
                        
                        i = (int) (Math.random() * danoVIC.length);       
                           
                        setDano(danoVIC[i]);
                    break;
                    
                    case "Raro":
                        double[] danoVRC = {12, 13.5, 15};
                        
                        i = (int) (Math.random() * danoVRC.length);       
                            
                        setDano(danoVRC[i]);
                    break;
                    
                    case "Lendário": 
                        double[] danoVLC = {19.5, 21, 23};
                        
                        i = (int) (Math.random() * danoVLC.length);       
                            
                        setDano(danoVLC[i]);
                    break;
                }
            break;
            
            case "Arco":
                //Dano por raridade:
                switch(getRaridade()){
                    case "Comum":
                        double[] danoVCA = {5, 5.5, 6};
                        
                        i = (int) (Math.random() * danoVCA.length);       
                            
                        setDano(danoVCA[i]);
                    break;
                    
                    case "Incomum":
                        double[] danoVIA = {8.5, 9, 9.5};
                        
                        i = (int) (Math.random() * danoVIA.length);       
                           
                        setDano(danoVIA[i]);
                    break;
                    
                    case "Raro":
                        double[] danoVRA = {12, 13, 14};
                        
                        i = (int) (Math.random() * danoVRA.length);       
                            
                        setDano(danoVRA[i]);
                    break;
                    
                    case "Lendário": 
                        double[] danoVLA = {17, 21, 21.5};
                        
                        i = (int) (Math.random() * danoVLA.length);       
                            
                        setDano(danoVLA[i]);
                    break;
                }
            break;
            
            case "Espada":
                //Dano por raridade:
                switch(getRaridade()){
                    case "Comum":
                        double[] danoVCE = {7, 8, 9};
                         
                        i = (int) (Math.random() * danoVCE.length);       
                            
                        setDano(danoVCE[i]);
                    break;
                    
                    case "Incomum":
                        double[] danoVIE = {9.5, 10.5, 11.5};
                        
                        i = (int) (Math.random() * danoVIE.length);       
                        
                        setDano(danoVIE[i]);
                    break;
                    
                    case "Raro":
                        double[] danoVRE = {13.5, 14, 15.5};
                        
                        i = (int) (Math.random() * danoVRE.length);       
                            
                        setDano(danoVRE[i]);
                    break;
                    
                    case "Lendário":
                        double[] danoVLE = {20, 22, 24};

                        i = (int) (Math.random() * danoVLE.length);       
                            
                        setDano(danoVLE[i]);
                    break;
                }
            break;
            
            default:
                double[] danoD = {8, 9, 10};
                i = (int) (Math.random() * danoD.length);
                
                setDano(danoD[i]);
            break;
        }   
    }
    
    //Getters:
    public double getDano(){
        return dano;
    }
    
    //Setters:
    public void setDano(double dano){
        this.dano = dano;
    }
    
    //Adders:
    public void addDano(double dano){
        this.dano += dano;
    }
}