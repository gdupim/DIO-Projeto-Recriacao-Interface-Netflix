package jogorpg;
public class GerarHeroi extends Personagens{
    //Variáveis:
    private int municao = 0, exp = 0, nivel = 0;
    private double mana = 0;  

    //Construtor:
    public GerarHeroi(String nome, String raca, double vida, double armadura, int municao, double mana, int exp, int nivel){
        super(nome, raca, vida, armadura);
        this.municao = municao;
        this.mana = mana;
        this.exp = exp;
        this.nivel = nivel;
    }
    
    //Geradores:
    public void gerarVida(int dificuldade){
        double[] vidaV = {50, 100, 115};
        
        switch(dificuldade){
            case 1:
               setVida(vidaV[2]); 
            break;
            
            case 2:
                setVida(vidaV[1]);
            break;
            
            case 3:
                setVida(vidaV[0]);
            break;
        }
    }
    
    public void gerarArmadura(int dificuldade){
        double[] armaduraV = {0, 15, 50};
        
        switch(dificuldade){
            case 1:
                setArmadura(armaduraV[2]);
            break;
            
            case 2:
                setArmadura(armaduraV[1]);
            break;
            
            case 3:
                setArmadura(armaduraV[0]);
            break;
        }
    }
    
    //Getters:
    public int getMunicao(){
        return municao;
    }
    
    public double getMana(){
        return mana;
    }
    
    public int getExp(){
        return exp;
    }
    
    public int getNivel(){
        return nivel;
    }
    
    //Setters:   
    public void setMunicao(int municao){
        this.municao = municao;
    }
    
    public void setMana(double mana){
        this.mana = mana;
    }
    
    public void setExp(int exp){
        this.exp = exp;
    }
    
    public void setNivel(int nivel){
        this.nivel = nivel;
    }
    
    //Adders:
    public void addMunicao(int municao){
        this.municao += municao;
    }
    
    public void addMana(double mana){
        this.mana += mana;
    }
    
    public void addExp(int exp){
        this.exp += exp;
    }
    
    public void addNivel(int nivel){
        this.nivel += nivel;
    }
}